<?php
/**
 * Created by PhpStorm.
 * User: Owner
 * Date: 12/14/2018
 * Time: 5:07 AM
 */
namespace SimplifiedMagento\FirstModule\NotMagento;


interface PencilInterface{


    public function getPencilType();
}